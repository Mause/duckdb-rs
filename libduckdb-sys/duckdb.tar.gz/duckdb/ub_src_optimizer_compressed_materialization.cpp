#include "src/optimizer/compressed_materialization/compress_aggregate.cpp"

#include "src/optimizer/compressed_materialization/compress_distinct.cpp"

#include "src/optimizer/compressed_materialization/compress_order.cpp"

