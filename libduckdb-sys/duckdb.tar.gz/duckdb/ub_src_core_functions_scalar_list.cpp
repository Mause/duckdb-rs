#include "src/core_functions/scalar/list/array_slice.cpp"

#include "src/core_functions/scalar/list/flatten.cpp"

#include "src/core_functions/scalar/list/list_aggregates.cpp"

#include "src/core_functions/scalar/list/list_lambdas.cpp"

#include "src/core_functions/scalar/list/list_value.cpp"

#include "src/core_functions/scalar/list/list_sort.cpp"

#include "src/core_functions/scalar/list/range.cpp"

