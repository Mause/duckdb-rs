#include "src/parser/transform/tableref/transform_base_tableref.cpp"

#include "src/parser/transform/tableref/transform_join.cpp"

#include "src/parser/transform/tableref/transform_from.cpp"

#include "src/parser/transform/tableref/transform_pivot.cpp"

#include "src/parser/transform/tableref/transform_subquery.cpp"

#include "src/parser/transform/tableref/transform_table_function.cpp"

#include "src/parser/transform/tableref/transform_tableref.cpp"

