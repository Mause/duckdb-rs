#include "src/catalog/catalog_entry/copy_function_catalog_entry.cpp"

#include "src/catalog/catalog_entry/duck_index_entry.cpp"

#include "src/catalog/catalog_entry/duck_schema_entry.cpp"

#include "src/catalog/catalog_entry/duck_table_entry.cpp"

#include "src/catalog/catalog_entry/type_catalog_entry.cpp"

#include "src/catalog/catalog_entry/index_catalog_entry.cpp"

#include "src/catalog/catalog_entry/macro_catalog_entry.cpp"

#include "src/catalog/catalog_entry/pragma_function_catalog_entry.cpp"

#include "src/catalog/catalog_entry/schema_catalog_entry.cpp"

#include "src/catalog/catalog_entry/sequence_catalog_entry.cpp"

#include "src/catalog/catalog_entry/table_catalog_entry.cpp"

#include "src/catalog/catalog_entry/column_dependency_manager.cpp"

#include "src/catalog/catalog_entry/scalar_function_catalog_entry.cpp"

#include "src/catalog/catalog_entry/table_function_catalog_entry.cpp"

#include "src/catalog/catalog_entry/view_catalog_entry.cpp"

