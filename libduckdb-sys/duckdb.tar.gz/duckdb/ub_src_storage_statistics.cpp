#include "src/storage/statistics/base_statistics.cpp"

#include "src/storage/statistics/column_statistics.cpp"

#include "src/storage/statistics/distinct_statistics.cpp"

#include "src/storage/statistics/list_stats.cpp"

#include "src/storage/statistics/numeric_stats.cpp"

#include "src/storage/statistics/numeric_stats_union.cpp"

#include "src/storage/statistics/segment_statistics.cpp"

#include "src/storage/statistics/string_stats.cpp"

#include "src/storage/statistics/struct_stats.cpp"

